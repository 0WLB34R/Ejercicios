public class Client {

	public static void main(String[] args) {

		Ventanilla.getInstance(); 										//Se instancia la ventanilla por primera vez 
		Ventanilla.getInstance().myInstnace();							//Se verifica la instancia
		System.out.println();
		Ventanilla.getInstance().registroDeCajero(26754);               //Se registra el cajero
		System.out.println();
		Ventanilla.getInstance().dineroExistente();           	        //Se verifica cuanto dinero hay en la caja
		System.out.println();
		Ventanilla.getInstance().pago(123.00);							//Pago del primer estudiante
		System.out.println();
		Ventanilla.getInstance().pago(123.00);							//Pago del segundo estudiante
		System.out.println();
		Ventanilla.getInstance().pago(144.50);							//Pago del tercer estudiante
		System.out.println();
		Ventanilla.getInstance().registroDeCajero(55940);               //Se registra otro cajero
		System.out.println();
		Ventanilla.getInstance().pago(105.50);							//Pago del cuarto estudiante
		System.out.println();
		Ventanilla.getInstance().pago(110.50);							//Pago del quinto estudiante
		System.out.println();
		Ventanilla.getInstance().dineroExistente();           	        //Se verifica otra vez cuanto dinero hay en la caja
		System.out.println();
		Ventanilla.getInstance().myInstnace();							//Se Comprueba la instancia

	}

}
