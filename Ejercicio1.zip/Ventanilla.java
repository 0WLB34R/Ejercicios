
public class Ventanilla {

	private static Ventanilla myInstance = null;
	private int codigo;
	private double plata;

	private Ventanilla() {
			setPlata(2000);
		}

	public static Ventanilla getInstance() {
		if (myInstance == null) {
			myInstance = new Ventanilla();
		}
		return myInstance;
	}
	
	public void registroDeCajero(int codigo) {
		this.codigo=codigo;
		System.out.println("Bienvenido cajer@: "+getCodigo());
	}
	
	public void pago(double monto) {
		this.plata=getPlata()+monto;
		System.out.println("El dinero en la caja es: "+getPlata());
	}
	
	public void dineroExistente() {
		System.out.println("El dinero actual en la caja es de: "+getPlata());
	}
	
	public void myInstnace() {
		System.out.println("Instancia: "+myInstance.hashCode());
	}

	public int getCodigo() {
		return codigo;
	}
	

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public double getPlata() {
		return plata;
	}

	public void setPlata(double plata) {
		this.plata = plata;
	}
	
	

}
