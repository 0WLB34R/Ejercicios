
public class Chef {
	
	private Builder builder;

	public Pizza getPizza() {
		return builder.getPizza();
	}

	public void setProductoBuilder(Builder builder) {
		this.builder = builder;
	}

	public void buildProduct() {
		builder.createPizza();
		builder.buildMasa();
		builder.buildSalsa();
		builder.buildQueso();
		builder.buildToppings();
	}
	
}
