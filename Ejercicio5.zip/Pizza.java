
public class Pizza {
	String masa;
	String salsa;
	String queso;
	String toppings;
	
	public String getMasa() {
		return masa;
	}
	public void setMasa(String masa) {
		this.masa = masa;
	}
	public String getSalsa() {
		return salsa;
	}
	public void setSalsa(String salsa) {
		this.salsa = salsa;
	}
	public String getQueso() {
		return queso;
	}
	public void setQueso(String queso) {
		this.queso = queso;
	}
	public String getToppings() {
		return toppings;
	}
	public void setToppings(String toppings) {
		this.toppings = toppings;
	}
	
	
	
}
