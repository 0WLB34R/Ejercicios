
public class Client {

	public static void main(String[] args) {

		Chef chef = new Chef();

		ConcreteBuilderHawaiiana concreteBuilderHawaiiana = new ConcreteBuilderHawaiiana();
		
		chef.setProductoBuilder(concreteBuilderHawaiiana);

		chef.buildProduct();

		Pizza pizzaHaw = chef.getPizza();

		ConcreteBuilderCarnivora concreteBuilderCarnivora = new ConcreteBuilderCarnivora();
		
		chef.setProductoBuilder(concreteBuilderCarnivora);

		chef.buildProduct();

		Pizza pizzaCar = chef.getPizza();
		
		System.out.println("Pizza 1: ");
		System.out.println("Masa: "+pizzaHaw.getMasa());
		System.out.println("Salsa: "+pizzaHaw.getSalsa());
		System.out.println("Queso: "+pizzaHaw.getQueso());
		System.out.println("Toppings: "+pizzaHaw.getToppings());
		System.out.println();
		System.out.println("Pizza 2: ");
		System.out.println("Masa: "+pizzaCar.getMasa());
		System.out.println("Salsa: "+pizzaCar.getSalsa());
		System.out.println("Queso: "+pizzaCar.getQueso());
		System.out.println("Toppings: "+pizzaCar.getToppings());
	}

}
