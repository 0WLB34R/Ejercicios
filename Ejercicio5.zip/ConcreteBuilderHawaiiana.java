
public class ConcreteBuilderHawaiiana extends Builder{

	@Override
	public void buildMasa() {
		
		pizza.setMasa("Ligera");
		
	}

	@Override
	public void buildSalsa() {
		
		pizza.setSalsa("Tomate y Cherry");
		
	}

	@Override
	public void buildQueso() {
		
		pizza.setQueso("Mozarella");
		
	}

	@Override
	public void buildToppings() {
		
		pizza.setToppings("Anana y Jamon");
		
	}

}
