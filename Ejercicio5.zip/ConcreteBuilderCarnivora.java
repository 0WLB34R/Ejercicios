
public class ConcreteBuilderCarnivora extends Builder{

	@Override
	public void buildMasa() {
		
		pizza.setMasa("Pesada");
		
	}

	@Override
	public void buildSalsa() {
		
		pizza.setSalsa("Tomate y BBQ");
		
	}

	@Override
	public void buildQueso() {
		
		pizza.setQueso("Parmesano");
		
	}

	@Override
	public void buildToppings() {
		
		pizza.setToppings("Carne, Tocino, Jamon, Pepperoni");
		
	}

}
