
public class Client {

	public static void main(String[] args) {
		
		KitColegial colegial = new ConcreteCreatorKC().FactoryMethodProduct();
		KitEscolar escolar = new ConcreteCreatorKE().FactoryMethodProduct();

	}

}
