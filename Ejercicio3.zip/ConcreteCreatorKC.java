
public class ConcreteCreatorKC extends CreatorKC{

	@Override
	public KitColegial FactoryMethodProduct() {
		
		KitColegial kitColegial = new KitColegial();
		Mochila mochila = new Mochila();
		Libros libros = new Libros();
		Computadora computadora = new Computadora();
		
		kitColegial.setMochila(mochila);
		kitColegial.setLibros(libros);
		kitColegial.setComputadora(computadora);
		return new KitColegial();
	}
}	