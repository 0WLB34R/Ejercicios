
public class Deportivo {

	private int talla;
	private String color;
	private int numeroPrendas;
	
}
