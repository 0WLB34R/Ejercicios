
public interface IKit {
	void create();
}
