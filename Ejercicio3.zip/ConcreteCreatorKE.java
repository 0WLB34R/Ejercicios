
public class ConcreteCreatorKE extends CreatorKE{

	@Override
	public KitEscolar FactoryMethodProduct() {
		
		KitEscolar kitEscolar = new KitEscolar();
		Mochila mochila = new Mochila();
		Deportivo deportivo = new Deportivo();
		Cuaderno cuaderno = new Cuaderno();
		
		kitEscolar.setCuaderno(cuaderno);
		kitEscolar.setDeportivo(deportivo);
		kitEscolar.setMochila(mochila);
		return new KitEscolar();
	}
	
	
}
