
public abstract class CreatorKE {
	public CreatorKE() {
		
	}
	
	public abstract KitEscolar FactoryMethodProduct(); 
}
