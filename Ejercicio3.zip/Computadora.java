
public class Computadora {

	private String marca;
	private String os;
	
}
