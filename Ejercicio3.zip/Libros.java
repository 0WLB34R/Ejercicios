
public class Libros {

	private String tipo;
	private String autor;
	
}
