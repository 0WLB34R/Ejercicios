
public class Mochila {

	private int bolsillos;
	private int tamanio;

}
