
public abstract class CreatorKC {
	public CreatorKC() {
		
	}
	
	public abstract KitColegial FactoryMethodProduct(); 
}
