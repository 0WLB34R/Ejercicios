
public class Cuaderno {

	private String tipo;
	private int hojas;
	
}
