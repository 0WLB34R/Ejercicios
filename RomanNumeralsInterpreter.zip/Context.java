
public class Context {
	protected String input = "";

	protected int output = 0;

	public Context(String input) {
		this.input = input;
	}
}
