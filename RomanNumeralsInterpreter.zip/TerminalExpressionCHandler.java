
public class TerminalExpressionCHandler extends AbstractExpression{

	@Override
	public void interpreter(Context context) {
		
		if (context.input.startsWith("CD")) {
			context.output = context.output + 400;
			context.input = context.input.substring(2);
		} else if (context.input.startsWith("CM")) {
			context.output = context.output + 900;
			context.input = context.input.substring(2);
		} else if (context.input.startsWith("C")) {
			context.output = context.output + 100;
			context.input = context.input.substring(1);
		}

		
	}
}