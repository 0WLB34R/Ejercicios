
public class TerminalExpressionIHandler extends AbstractExpression {

	@Override
	public void interpreter(Context context) {

		if (context.input.startsWith("IV")) {
			context.output = context.output + 4;
			context.input = context.input.substring(2);
		} else if (context.input.startsWith("IX")) {
			context.output = context.output + 9;
			context.input = context.input.substring(2);
		} else if (context.input.startsWith("I")) {
			context.output = context.output + 1;
			context.input = context.input.substring(1);
		}

	}
}
