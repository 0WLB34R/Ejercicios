
public abstract class AbstractExpression {
	public abstract void interpreter(Context context);
}
