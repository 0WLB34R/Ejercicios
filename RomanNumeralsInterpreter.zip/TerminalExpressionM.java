
public class TerminalExpressionM extends AbstractExpression{

	@Override
	public void interpreter(Context context) {
		
		if (context.input.startsWith("M")) {
			context.output = context.output + 1000;
			context.input = context.input.substring(1);
		}
		
	}

}
