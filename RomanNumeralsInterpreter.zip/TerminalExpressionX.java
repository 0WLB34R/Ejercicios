
public class TerminalExpressionX extends AbstractExpression{

	@Override
	public void interpreter(Context context) {
		
		if (context.input.startsWith("XC")) {
			context.output = context.output + 90;
			context.input = context.input.substring(2);
		} else if (context.input.startsWith("XL")) {
			context.output = context.output + 40;
			context.input = context.input.substring(2);
		} else if (context.input.startsWith("X")) {
			context.output = context.output + 10;
			context.input = context.input.substring(1);
		}

		
	}
}
