import java.util.Scanner;

public class Client {

	public static void main(String[] args) {
		
		System.out.print("Enter a number: ");
		Scanner sc = new Scanner (System.in);
		
		String toInterpret = sc.nextLine();
		
		System.out.println("\nEvaluate: "+toInterpret+"\nIntrepret: "+new Parser(toInterpret).evaluate());
		
		sc.close();

	}

}
