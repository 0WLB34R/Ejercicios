
public class TerminalExpressionL extends AbstractExpression{

	@Override
	public void interpreter(Context context) {
		
		if (context.input.startsWith("L")) {
			context.output = context.output + 50;
			context.input = context.input.substring(1);
		}
		
	}

}
