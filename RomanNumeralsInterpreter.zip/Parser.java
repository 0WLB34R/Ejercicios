import java.util.ArrayList;

public class Parser {
	private ArrayList<AbstractExpression> parseTree = new ArrayList<>();
	private Context context;
	
	public Parser(String s) {
		s = s.replace(" ","");
		s = s.toUpperCase();
		context = new Context(s);
		for (String token : s.split("")) {
			switch (token) {
			
			case "I":
				parseTree.add(new TerminalExpressionIHandler());
				break;
				
			case "V":
				parseTree.add(new TerminalExpressionV());
				break;
				
			case "X":
				parseTree.add(new TerminalExpressionX());
				break;
				
			case "L":
				parseTree.add(new TerminalExpressionL());
				break;
				
			case "D":
				parseTree.add(new TerminalExpressionD());
				break;
				
			case "M":
				parseTree.add(new TerminalExpressionM());
				break;
				
			case "C":
				parseTree.add(new TerminalExpressionCHandler());
				break;
				
			default:
				break;
			}
		}
	}
	
	public int evaluate() {
		for (AbstractExpression e : parseTree) {
			e.interpreter(context);
		}
		return context.output;
	}
}
