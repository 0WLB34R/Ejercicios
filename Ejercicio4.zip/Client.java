
public class Client {
	public static void main(String[] args) {
		ConcreteMat primeraInscripcion = (ConcreteMat) AbstractFactoryProduct.make(Materia.MATEMATICA, "Jose");
		ConcreteHis segundaInscripcion = (ConcreteHis) AbstractFactoryProduct.make(Materia.HISTORIA, "Carlos");
		ConcreteLen terceraInscripciom = (ConcreteLen) AbstractFactoryProduct.make(Materia.LENGUAJE, "Lucho");
		ConcreteIng cuartaInscripcion = (ConcreteIng) AbstractFactoryProduct.make(Materia.INGLES, "Miguel");
		ConcreteMat quintaIncripcion = (ConcreteMat) AbstractFactoryProduct.make(Materia.MATEMATICA, "Andres");
		
		System.out.println("Matematicas:");
		System.out.println(primeraInscripcion.getEstudiante());
		System.out.println(quintaIncripcion.getEstudiante());
		System.out.println();
		System.out.println("Historia:");
		System.out.println(segundaInscripcion.getEstudiante());
		System.out.println();
		System.out.println("Lenguaje:");
		System.out.println(terceraInscripciom.getEstudiante());
		System.out.println();
		System.out.println("Ingles:");
		System.out.println(cuartaInscripcion.getEstudiante());
		
		
	}
}
