
public enum Materia {
	MATEMATICA,
	HISTORIA,
	LENGUAJE,
	INGLES;
}
