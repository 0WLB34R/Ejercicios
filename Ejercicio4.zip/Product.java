
public abstract class Product {
	abstract public void operation();
}
