
public class ConcreteIng implements IEstudiante{
	private String estudiante;
	
	ConcreteIng (String estudiante){
		this.estudiante=estudiante;
	}
	
	
	public String getEstudiante() {
		return estudiante;
	}


	public void setEstudiante(String estudiante) {
		this.estudiante = estudiante;
	}


	@Override
	public void operation() {
	
	}

}