
public interface IEstudiante {
	void operation();
}
