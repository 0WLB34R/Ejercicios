
public class ConcreteLen implements IEstudiante{
	private String estudiante;
	
	ConcreteLen (String estudiante){
		this.estudiante=estudiante;
	}
	
	
	public String getEstudiante() {
		return estudiante;
	}


	public void setEstudiante(String estudiante) {
		this.estudiante = estudiante;
	}


	@Override
	public void operation() {
	
	}

}