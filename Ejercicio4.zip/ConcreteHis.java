
public class ConcreteHis implements IEstudiante{
	private String estudiante;
	
	ConcreteHis (String estudiante){
		this.estudiante=estudiante;
	}
	
	
	public String getEstudiante() {
		return estudiante;
	}


	public void setEstudiante(String estudiante) {
		this.estudiante = estudiante;
	}


	@Override
	public void operation() {
	
	}

}
