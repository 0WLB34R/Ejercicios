public class AbstractFactoryProduct {
	public static IEstudiante make(Materia respuesta, String nombre) {

		IEstudiante product;

		switch (respuesta) {

		case MATEMATICA:
			product = new ConcreteMat(nombre);
			break;

		case HISTORIA:
			product = new ConcreteHis(nombre);
			break;

		case LENGUAJE:
			product = new ConcreteLen(nombre);
			break;

		case INGLES:
			product = new ConcreteIng(nombre);
			break;

		default:
			product = new ConcreteMat(nombre);
			break;
		}
		return product;
	}
}
