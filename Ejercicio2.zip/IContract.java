
public interface IContract extends Cloneable{
	Object clone();
}
