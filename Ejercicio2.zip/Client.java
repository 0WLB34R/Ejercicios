
public class Client {

	public static void main(String[] args) {
		
		//Clonacion con nombres nuevos
		ConcreteContract uno = new ConcreteContract("Sergio", "Lopez");		
		ConcreteContract dos = (ConcreteContract) uno.clone("Andres", "Quezada");
		ConcreteContract tres = (ConcreteContract) uno.clone("Julio", "Torres");
		ConcreteContract cuatro = (ConcreteContract) uno.clone("Luis", "Bor");
		ConcreteContract cinco = (ConcreteContract) uno.clone("Carlos", "Nils");
		ConcreteContract seis = (ConcreteContract) uno.clone("Sandra", "Castillo");
		ConcreteContract siete = (ConcreteContract) uno.clone("Patric", "Luz");
		ConcreteContract ocho = (ConcreteContract) uno.clone("Julian", "Lopez");
		ConcreteContract nueve = (ConcreteContract) uno.clone("Julia", "Luisa");
		ConcreteContract dies = (ConcreteContract) uno.clone("Carmen", "Gomez");
		ConcreteContract once = (ConcreteContract) uno.clone("Tomas", "Rios");
		ConcreteContract doce = (ConcreteContract) uno.clone("Andres", "Puentes");
		ConcreteContract trece = (ConcreteContract) uno.clone("Carla", "Gutierrez");
		ConcreteContract catorce = (ConcreteContract) uno.clone("Jaime", "Borga");
		ConcreteContract quince = (ConcreteContract) uno.clone("Luis", "Quezada");
		
		//Comprobar
		System.out.println("Primer Contrato");
		System.out.println(uno.getNombre());
		System.out.println(uno.getSueldo());
		
		System.out.println("Segundo Contrato");
		System.out.println(dos.getNombre());
		System.out.println(dos.getSueldo());

	}

}
