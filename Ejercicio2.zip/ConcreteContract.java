
public class ConcreteContract {

	//Attributes	
	private int sueldo = 5000;
	private int cargaHoraria = 80;
	private boolean cursoEducacionSuperior = true;
	private boolean accesoPlataforma = true;
	private boolean marcadoBiometrico = false;
	private String horaEntrada = "08:00";
	private String horaSalida = "08:00";
	private String nombre;
	private String apellido;
	
	//Methods
	public int getSueldo() {
		return sueldo;
	}
	public void setSueldo(int sueldo) {
		this.sueldo = sueldo;
	}
	public int getCargaHoraria() {
		return cargaHoraria;
	}
	public void setCargaHoraria(int cargaHoraria) {
		this.cargaHoraria = cargaHoraria;
	}
	public boolean isCursoEducacionSuperior() {
		return cursoEducacionSuperior;
	}
	public void setCursoEducacionSuperior(boolean cursoEducacionSuperior) {
		this.cursoEducacionSuperior = cursoEducacionSuperior;
	}
	public boolean getAccesoPlataforma() {
		return accesoPlataforma;
	}
	public void setAccesoPlataforma(boolean accesoPlataforma) {
		this.accesoPlataforma = accesoPlataforma;
	}
	public boolean isMarcadoBiometrico() {
		return marcadoBiometrico;
	}
	public void setMarcadoBiometrico(boolean marcadoBiometrico) {
		this.marcadoBiometrico = marcadoBiometrico;
	}
	public String getHoraEntrada() {
		return horaEntrada;
	}
	public void setHoraEntrada(String horaEntrada) {
		this.horaEntrada = horaEntrada;
	}
	public String getHoraSalida() {
		return horaSalida;
	}
	public void setHoraSalida(String horaSalida) {
		this.horaSalida = horaSalida;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	
	public ConcreteContract (String nombre, String apellido){
		setApellido(apellido);
		setNombre(nombre);
	}
	
	public Object clone(String nombre, String apellido) {
		ConcreteContract cloneObj = new ConcreteContract(nombre, apellido);
		cloneObj.sueldo=this.sueldo;
		cloneObj.cargaHoraria=this.cargaHoraria;
		cloneObj.cursoEducacionSuperior=this.cursoEducacionSuperior;
		cloneObj.accesoPlataforma=this.accesoPlataforma;
		cloneObj.marcadoBiometrico=this.marcadoBiometrico;
		cloneObj.horaEntrada=this.horaEntrada;
		cloneObj.horaSalida=this.horaSalida;
		return cloneObj;
	}
	
	
}
